package list3;

public class listing3_25 {
}

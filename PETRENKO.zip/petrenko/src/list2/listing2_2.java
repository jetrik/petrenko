package list2;

class AssignExample {
    AssignExample() {
    }

    public static void main(String[] arge) {
        int var1 = 4069;
        int var2 = var1 / 4;
        System.out.println("var1=" + var1);
        System.out.println("var2=var1/4=" + var2);
    }
}


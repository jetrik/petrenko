package list2;

class BoolDemo {
    BoolDemo() {
    }

    public static void main(String[] args) {
        boolean b = false;
        System.out.println("b равно " + b);
        b = true;
        System.out.println("b равно " + b);
        if (b) {
            System.out.println("Как вы думаете, увидите ли вы эту строчку?");
        }

        System.out.println("выражение 10 > 9 имеет значение true");
    }
}


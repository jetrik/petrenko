package list2;

class BlockDemo {
    BlockDemo() {
    }

    public static void main(String[] args) {
        double i = 50.0;
        double j = 150.0;
        if (i != 0.0) {
            System.out.println("делитель не равен нулю");
            double d = j / i;
            System.out.println(" j/i равно " + d);
        }

    }
}
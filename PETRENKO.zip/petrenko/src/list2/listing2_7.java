package list2;

class HypotDemo {
    HypotDemo() {
    }

    public static void main(String[] args) {
        double cathetus1 = 3.0;
        double cathetus2 = 4.0;
        double hypot = Math.sqrt(cathetus1 * cathetus1 + cathetus2 * cathetus2);
        System.out.println(" длинна гипотенузы равна " + hypot);
    }
}
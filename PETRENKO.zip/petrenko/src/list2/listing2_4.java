package list2;

class ForStatementDemo {
    ForStatementDemo() {
    }

    public static void main(String[] arge) {
        for(int count = 0; count < 5; ++count) {
            System.out.println("Переменна цикла равна" + count);
        }

        System.out.println("Цикл окончен");
    }
}
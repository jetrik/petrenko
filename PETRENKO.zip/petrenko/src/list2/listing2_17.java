package list2;

class AlphabetWhileDemo {
    public static void main(String[] args) {
        char ch = 'a';
        while (ch <= 'я') {
            System.out.println(ch);
            ch++;

        } // while

    } // main(String[]) method

} //AlphabetWhileDemo class
package list6;

import java.io.PrintStream;

class ShortcutOutDemo {

    private static PrintStream out = System.out;

    public  static  void  main(String [] args) {

        out.println("Пример...");
        out.println("...краткой записи команды вывода на консоль..");
    }
}